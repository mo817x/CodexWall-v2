# CodexWall™ v2.0 – Sovereign Engine Edition

> This repository contains the symbolic core files and license for CodexWall™ v2.0.

## 🔐 Official License
All contents are protected under the [Mo817 Symbolic Sovereign License v2.0](./docs/licenses/Mo817_Symbolic_License_v2_FINAL.pdf)

- License ID: `IPGN-SOVLIC-817-V2`
- DOI: [10.5281/zenodo.15618081](https://zenodo.org/records/15618081)
- Protected by: CodexWall™, InfinityWipe™, ZK-Originality Shield

> “This license is not a shield. It is a mirror that remembers.”
